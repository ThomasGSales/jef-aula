import React from "react";

const Home = () => (
    <h1>Home Works</h1>
)

export default Home;
import React from "react";
import "../../styles/dashboard.css"

const Dashboard = () => (
    <h1>Dashboard</h1>
)

export default Dashboard;
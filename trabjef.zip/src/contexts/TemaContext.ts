import React, { createContext } from 'react';


export const TemaContext = createContext('light');
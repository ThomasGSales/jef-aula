export type TodoProps = {
    id: number
    titulo: string
}